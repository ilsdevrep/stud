﻿https://yadi.sk/d/WeAccJ7g5aeZj

7 Семестр/UNSORTED/OS/ос/ос/-----
7 Семестр/UNSORTED/OS/ос/ос/7_os_lab7/temp/2